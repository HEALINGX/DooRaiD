npm install @react-navigation/native @react-navigation/bottom-tabs @react-navigation/stack @expo/vector-icons react-native-screens react-native-safe-area-context
 
