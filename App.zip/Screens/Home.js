import { StatusBar } from 'expo-status-bar';
import { collection, getDocs } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, FlatList, SafeAreaView, Image, TouchableOpacity } from 'react-native';
import { db } from '../Configs/Firebase';

export default function Home({ navigation }) {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const querySnapshot = await getDocs(collection(db, "Movie"));
      const docsData = querySnapshot.docs.map(doc => doc.data());
      setData(docsData);
    };
    fetchData();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <TouchableOpacity style={styles.imageContainer} onPress={() => navigation.navigate('Details', { item })}>
        <Image style={styles.image} source={{ uri: item.movie_image }} />
      </TouchableOpacity>
      <Text style={styles.title} onPress={() => navigation.navigate('Details', { item })}>
        {"\n"}{item.movie_name}
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={data}
        horizontal = {true}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
      />
      <StatusBar style="auto" />
    </SafeAreaView>
    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  item: {
    backgroundColor: '#fff',
    padding: 20,
    marginHorizontal: 1,
    marginVertical: 25,
  },
  title: {
    fontSize: 20,
    textAlign: 'center',
    width: 300,
    height: 500,
  },
  imageContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 300,
    height: 500,
    borderRadius: 20
  },
});
