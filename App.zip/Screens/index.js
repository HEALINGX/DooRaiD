import Home from "./Home";
import Category from "./Category";

export {
    Home,
    Category
}